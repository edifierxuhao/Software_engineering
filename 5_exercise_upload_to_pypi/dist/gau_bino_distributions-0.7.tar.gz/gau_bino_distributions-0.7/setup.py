from setuptools import setup

setup(name='gau_bino_distributions',
      version='0.7',
      description='Gaussian and Binomial Distributions',
      packages=['gau_bino_distributions'],
      author = 'Hao Xu',
      author_email = 'edifierxuhao123@gmail.com',
      zip_safe=False)